
const router = require("express").Router();

router.post("/chat", async (req,res)=>{
 const {message} = req.body;
 res.json({reply:"AI says: " + message});
});

module.exports = router;
