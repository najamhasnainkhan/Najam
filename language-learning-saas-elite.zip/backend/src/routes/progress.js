
const router = require("express").Router();

let progressData = [];

router.get("/", (req,res)=>res.json(progressData));

router.post("/", (req,res)=>{
 progressData.push(req.body);
 res.json({msg:"saved"});
});

module.exports = router;
