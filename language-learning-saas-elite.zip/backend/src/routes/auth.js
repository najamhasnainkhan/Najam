
const router = require("express").Router();

router.post("/login", (req,res)=>{
 const {email} = req.body;
 res.json({token:"demo-token", user:{email}});
});

module.exports = router;
