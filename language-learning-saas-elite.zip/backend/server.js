
const express = require("express");
const cors = require("cors");
const helmet = require("helmet");

const app = express();
app.use(cors());
app.use(helmet());
app.use(express.json());

app.use("/api/auth", require("./src/routes/auth"));
app.use("/api/ai", require("./src/routes/ai"));
app.use("/api/progress", require("./src/routes/progress"));

app.listen(5000, () => console.log("Elite SaaS backend running on 5000"));
