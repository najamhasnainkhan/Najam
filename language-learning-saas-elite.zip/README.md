
# Elite SaaS Language Learning App

## Features
- AI Chat system
- Auth system (starter)
- Progress tracking API
- SaaS-ready structure

## Run Backend
cd backend
npm install express cors helmet
node server.js

## Run Frontend
cd frontend
npm install
npm run dev

## Next Steps
- Add MongoDB
- Add JWT auth
- Integrate real AI API
- Deploy to cloud
