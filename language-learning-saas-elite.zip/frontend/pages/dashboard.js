
export default function Dashboard(){
 return (
  <div style={{padding:20}}>
   <h2>User Dashboard</h2>
   <p>Track your progress here (expand later)</p>
  </div>
 );
}
