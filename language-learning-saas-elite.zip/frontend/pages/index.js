
import { useState } from "react";

export default function Home(){
 const [msg,setMsg]=useState("");
 const [reply,setReply]=useState("");

 const send = async ()=>{
  const res = await fetch("http://localhost:5000/api/ai/chat",{
   method:"POST",
   headers:{"Content-Type":"application/json"},
   body:JSON.stringify({message:msg})
  });
  const data = await res.json();
  setReply(data.reply);
 };

 return (
  <div style={{padding:20}}>
   <h1>Elite AI Language App</h1>
   <input onChange={e=>setMsg(e.target.value)} placeholder="Talk..." />
   <button onClick={send}>Send</button>
   <p>{reply}</p>
  </div>
 );
}
