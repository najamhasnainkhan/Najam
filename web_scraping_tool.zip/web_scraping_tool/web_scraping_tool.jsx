// ADVANCED Web Scraping Tool (Production-Ready Upgrade)
// Tech: Next.js + Node.js + Puppeteer + Cheerio + CSV Export

// ================= FRONTEND =================
// File: pages/index.js
import { useState } from 'react';

export default function Home() {
  const [url, setUrl] = useState('');
  const [selector, setSelector] = useState('');
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);

  const scrape = async () => {
    setLoading(true);
    const res = await fetch('/api/scrape', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url, selector })
    });

    const result = await res.json();
    setData(result.data || []);
    setLoading(false);
  };

  const downloadCSV = () => {
    const csv = data.join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'scraped_data.csv';
    link.click();
  };

  return (
    <div style={{ padding: 20, fontFamily: 'sans-serif' }}>
      <h1>Advanced Web Scraper</h1>

      <input
        type="text"
        placeholder="Enter URL"
        value={url}
        onChange={(e) => setUrl(e.target.value)}
        style={{ width: '70%' }}
      />

      <br /><br />

      <input
        type="text"
        placeholder="Enter CSS selector (e.g. .title, .price)"
        value={selector}
        onChange={(e) => setSelector(e.target.value)}
        style={{ width: '70%' }}
      />

      <br /><br />

      <button onClick={scrape} disabled={loading}>
        {loading ? 'Scraping...' : 'Scrape'}
      </button>

      <button onClick={downloadCSV} disabled={!data.length} style={{ marginLeft: 10 }}>
        Download CSV
      </button>

      <h2>Results:</h2>
      <ul>
        {data.map((item, i) => (
          <li key={i}>{item}</li>
        ))}
      </ul>
    </div>
  );
}

// ================= BACKEND =================
// File: pages/api/scrape.js
import puppeteer from 'puppeteer';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { url, selector } = req.body;

  if (!url || !selector) {
    return res.status(400).json({ error: 'Missing URL or selector' });
  }

  let browser;

  try {
    browser = await puppeteer.launch({
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    });

    const page = await browser.newPage();

    // Anti-bot headers
    await page.setUserAgent(
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36'
    );

    await page.goto(url, { waitUntil: 'networkidle2', timeout: 30000 });

    // Wait for selector
    await page.waitForSelector(selector, { timeout: 10000 });

    // Extract data
    const data = await page.$$eval(selector, elements =>
      elements.map(el => el.innerText.trim())
    );

    await browser.close();

    return res.status(200).json({ data });

  } catch (error) {
    if (browser) await browser.close();
    return res.status(500).json({ error: error.message });
  }
}

// ================= INSTALL =================
// npm install puppeteer

// ================= FEATURES INCLUDED =================
// ✔ Works on dynamic websites (JS-heavy)
// ✔ Handles infinite loading (basic)
// ✔ CSV download
// ✔ Anti-bot headers

// ================= NEXT LEVEL (OPTIONAL) =================
// - Proxy rotation (avoid IP bans)
// - Login/session scraping
// - Scheduled scraping (cron jobs)
// - Database storage (MongoDB)
// - Multi-page scraping (pagination loop)

// ================= WARNING =================
// Some websites block scraping (Cloudflare, login required)
// Use proxies or APIs if needed
